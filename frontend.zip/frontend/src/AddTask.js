import React, { useState } from 'react';

function AddTask({ onAddTask }) {
  const [task, setTask] = useState('');
  const [priority, setPriority] = useState('Low');
  const [dueDate, setDueDate] = useState('');

  const handleAddTask = () => {
    if (task.trim() && dueDate) {
      onAddTask(task, priority, dueDate); // Pass due date
      setTask(''); // Clear input
      setPriority('Low'); // Reset priority
      setDueDate(''); // Reset due date
    } else {
      alert('Task and due date cannot be empty!');
    }
  };

  return (
    <div>
      <input
        type="text"
        placeholder="Add a new task"
        value={task}
        onChange={(e) => setTask(e.target.value)}
      />
      <select value={priority} onChange={(e) => setPriority(e.target.value)}>
        <option value="High">High</option>
        <option value="Medium">Medium</option>
        <option value="Low">Low</option>
      </select>
      <input
        type="date"
        value={dueDate}
        onChange={(e) => setDueDate(e.target.value)}
      />
      <button onClick={handleAddTask}>Add Task</button>
    </div>
  );
}

export default AddTask;

