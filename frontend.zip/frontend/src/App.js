import React, { useState, useEffect } from 'react';
import Header from './Header';
import TaskList from './TaskList';
import AddTask from './AddTask';

function App() {
  // Load tasks from local storage or set default tasks
  const [tasks, setTasks] = useState(() => {
    const savedTasks = localStorage.getItem('tasks');
    return savedTasks ? JSON.parse(savedTasks) : [];
  });

  // Define filter and search states
  const [filter, setFilter] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');

  // Save tasks to local storage whenever they change
  useEffect(() => {
    localStorage.setItem('tasks', JSON.stringify(tasks));
  }, [tasks]);

  // Function to add a new task
  const addTask = (taskText, taskPriority, taskDueDate) => {
    const newTask = {
      id: tasks.length + 1,
      text: taskText,
      priority: taskPriority,
      dueDate: taskDueDate,
      completed: false,
    };
    setTasks([...tasks, newTask]);
  };

  // Function to toggle task completion
  const toggleComplete = (taskId) => {
    setTasks(
      tasks.map((task) =>
        task.id === taskId ? { ...task, completed: !task.completed } : task
      )
    );
  };

  // Function to delete a task
  const deleteTask = (taskId) => {
    setTasks(tasks.filter((task) => task.id !== taskId));
  };

  // Function to filter tasks
  const getFilteredTasks = () => {
    let filteredTasks = tasks;

    // Apply priority and completion filters
    switch (filter) {
      case 'High':
      case 'Medium':
      case 'Low':
        filteredTasks = filteredTasks.filter((task) => task.priority === filter);
        break;
      case 'Completed':
        filteredTasks = filteredTasks.filter((task) => task.completed);
        break;
      case 'Pending':
        filteredTasks = filteredTasks.filter((task) => !task.completed);
        break;
      default:
        break;
    }

    // Apply search filter
    if (searchQuery.trim() !== '') {
      filteredTasks = filteredTasks.filter((task) =>
        task.text.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    return filteredTasks;
  };

  return (
    <div>
      <Header />
      <p>Welcome to your task management app!</p>
      <div>
        <label htmlFor="filter">Filter by: </label>
        <select
          id="filter"
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
          style={{ marginBottom: '10px' }}
        >
          <option value="All">All</option>
          <option value="High">High Priority</option>
          <option value="Medium">Medium Priority</option>
          <option value="Low">Low Priority</option>
          <option value="Completed">Completed</option>
          <option value="Pending">Pending</option>
        </select>
      </div>
      <div>
        <label htmlFor="search">Search: </label>
        <input
          id="search"
          type="text"
          placeholder="Search tasks..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          style={{ marginLeft: '10px', marginBottom: '10px' }}
        />
      </div>
      <AddTask onAddTask={addTask} />
      <TaskList tasks={getFilteredTasks()} onToggleComplete={toggleComplete} onDeleteTask={deleteTask} />
    </div>
  );
}

export default App;

