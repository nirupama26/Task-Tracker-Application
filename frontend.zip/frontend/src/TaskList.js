function TaskList({ tasks, onToggleComplete, onDeleteTask }) {
  // Sort tasks by priority: High > Medium > Low and then by due date
  const priorityOrder = { High: 1, Medium: 2, Low: 3 };
  const sortedTasks = [...tasks].sort((a, b) => {
    if (priorityOrder[a.priority] === priorityOrder[b.priority]) {
      // If priorities are the same, compare due dates
      return new Date(a.dueDate) - new Date(b.dueDate);
    }
    return priorityOrder[a.priority] - priorityOrder[b.priority];
  });

  // Function to get color based on priority
  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'High':
        return 'red';
      case 'Medium':
        return 'orange';
      case 'Low':
        return 'green';
      default:
        return 'black';
    }
  };

  return (
    <ul>
      {sortedTasks.map((task) => (
        <li
          key={task.id}
          style={{
            display: 'flex',
            alignItems: 'center',
            color: getPriorityColor(task.priority),
          }}
        >
          <span
            style={{
              textDecoration: task.completed ? 'line-through' : 'none',
              cursor: 'pointer',
              flex: 1,
            }}
            onClick={() => onToggleComplete(task.id)}
          >
            {task.text} - <strong>{task.priority}</strong> (Due: {task.dueDate})
          </span>
          <button
            style={{
              marginLeft: '10px',
              color: 'white',
              backgroundColor: 'red',
              border: 'none',
              borderRadius: '3px',
              cursor: 'pointer',
            }}
            onClick={() => onDeleteTask(task.id)}
          >
            Delete
          </button>
        </li>
      ))}
    </ul>
  );
}

export default TaskList;

